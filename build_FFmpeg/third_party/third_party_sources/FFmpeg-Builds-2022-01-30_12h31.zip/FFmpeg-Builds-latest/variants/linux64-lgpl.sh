#!/bin/bash
source "$(dirname "$BASH_SOURCE")"/default-install.sh
source "$(dirname "$BASH_SOURCE")"/defaults-lgpl.sh
